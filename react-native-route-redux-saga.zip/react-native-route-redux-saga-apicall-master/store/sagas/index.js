
import weatherSage from './weatherSage'

export default weatherSage;

// watcher saga  -> action => worker saga
 